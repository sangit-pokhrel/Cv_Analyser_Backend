import AllJobs from "./allJobs"
import Badge from "@/globals/badge";
import Container from "@/globals/container";
import { RiGeminiLine } from "react-icons/ri";
const AllJobsIndex = ()=>{
  return(
  <Container>
    <div>
    <AllJobs/>
    </div>
  </Container>
  )
}
export default AllJobsIndex;