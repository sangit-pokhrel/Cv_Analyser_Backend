
import Container from "@/globals/container";
import RecommendedJobs from "./recommendedJobs";
const RecommendedJobsIndex = ()=>{
  return(
  <Container>
    <RecommendedJobs/>
  </Container>
  )
}
export default RecommendedJobsIndex;