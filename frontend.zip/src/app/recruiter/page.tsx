import RecruiterDashboard from '@/components/recruiter/pages/RecruiterDashboard';

export default function RecruiterPage() {
  return <RecruiterDashboard />;
}
