import Contact from '@/components/admin/pages/Contact';

export default function ContactInquiriesPage() {
  return <Contact />;
}