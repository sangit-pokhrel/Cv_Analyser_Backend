import Support from '@/components/admin/pages/Support';

export default function SupportPage() {
  return <Support />;
}