import AdminDashboard from '@/components/admin/pages/AdminDashboard';

export default function AdminPage() {
  return <AdminDashboard />;
}