import Analytics from '@/components/admin/pages/Analytics';

export default function AnalyticsPage() {
  return <Analytics />;
}