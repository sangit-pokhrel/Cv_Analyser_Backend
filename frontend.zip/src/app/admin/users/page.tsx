import Users from '@/components/admin/pages/Users';

export default function UsersPage() {
  return <Users />;
}