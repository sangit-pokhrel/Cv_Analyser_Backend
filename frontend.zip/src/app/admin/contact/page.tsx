import Contact from '@/components/admin/pages/Contact';

export default function ContactPage() {
  return <Contact />;
}