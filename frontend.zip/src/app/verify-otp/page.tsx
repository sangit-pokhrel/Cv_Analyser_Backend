

'use client';

import VerifyOTPPage from './../../components/OtpVerifyPage';

export default function UserPage() {
  return <VerifyOTPPage />;
}