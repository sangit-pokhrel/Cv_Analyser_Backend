"use client"
import Navbar from "@/globals/navbar";
import React from "react";
 const RegisterLayout = ({children}:{children:React.ReactNode})=> {
  return (
    <div>
 
      {children}
    </div>
  )
} 
export default RegisterLayout;