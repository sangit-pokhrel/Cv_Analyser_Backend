
import ResetPasswordIndex from "@/components/ResetPassword";
const ResetPassword = ()=>{
return(
  <div>
   <ResetPasswordIndex/>
  </div>
)
}
export default ResetPassword;