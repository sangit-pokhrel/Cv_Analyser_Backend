
import JobsDetails from "@/components/JobsById";

const JobByIdPage = () => {
  return <JobsDetails />;
};
export default JobByIdPage;

