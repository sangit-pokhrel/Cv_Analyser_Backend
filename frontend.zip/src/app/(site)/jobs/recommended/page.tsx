import RecommendedJobsIndex from "@/components/RecommendedJobs";


const RecommendedJobs = ()=>{
  return(
    <RecommendedJobsIndex/>
  )
}
export default RecommendedJobs;