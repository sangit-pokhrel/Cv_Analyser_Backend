import AnalyseCvIndex from "@/components/AnalyseCvPage";


const AnalyseCvPage = ()=>{
  return (
    <div>
     <AnalyseCvIndex/>
    </div>
  )
}
export default AnalyseCvPage;