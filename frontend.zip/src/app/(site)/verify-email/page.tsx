import VerifyEmailIndex from "@/components/VerifyEmailPage";
const VerifyEmailPage = ()=>{
  return(
    <div>
     <VerifyEmailIndex/>
    </div>
  )
}
export default VerifyEmailPage;