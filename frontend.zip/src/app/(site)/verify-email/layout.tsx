import React from "react";

const VerifyEmailLayout =({children}:{children:React.ReactNode})=>{


  return(
    <div>
      {children}
    </div>
  )
}

export default VerifyEmailLayout;


