
import AnalyseCvIdIndex from "@/components/CvAnalysis-resultByIdComponents";
const AnalyseCvIdPage = ()=>{
  return (
    <AnalyseCvIdIndex/>
  )
}
export default AnalyseCvIdPage;