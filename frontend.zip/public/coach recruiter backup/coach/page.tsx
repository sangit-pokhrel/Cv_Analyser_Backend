


import CoachDashboard from '@/components/coach/pages/CoachDashboard';

export default function CoachPage() {
  return <CoachDashboard />;
}