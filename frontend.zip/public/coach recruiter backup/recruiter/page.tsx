import RecruiterDashboard from '@/components/recruiter/RecruiterDashboard';

export default function RecruiterPage() {
  return <RecruiterDashboard />;
}